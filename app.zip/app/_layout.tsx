// app/_layout.tsx
import 'react-native-get-random-values'; 
import React, { useEffect } from 'react';
import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { initDb } from '@/lib/database'; // 👈 قم بالتغيير هنا ليتجه إلى الملف الجديد
import * as SQLite from 'expo-sqlite';
import 'react-native-reanimated';

import { useColorScheme } from '@/hooks/useColorScheme';
import { Alert } from 'react-native'; // أضف هذا إذا لم يكن موجوداً
import NetInfo from '@react-native-community/netinfo'; // أضف هذا إذا لم يكن موجوداً


export default function RootLayout() {
  const colorScheme = useColorScheme();
  const [loaded] = useFonts({
    SpaceMono: require('../assets/fonts/SpaceMono-Regular.ttf'),
  });

  // يجب أن يكون setIsConnected في حالة ما، ولكن لأغراض العرض هنا، سأتركه كتعليق أو أزيله
  // const [isConnected, setIsConnected] = useState(false); // إذا كنت تستخدمه في مكان آخر، ضعه هنا

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    const initializeApp = async () => {
      try {
        await initDb(); // استدعاء دالة initDb العامة
        // إذا كان NetInfo و fetchLevels يتعلقان بتهيئة عامة للتطبيق، ابقيهما هنا
        // وإلا، انقل fetchLevels إلى المكون الذي يحتاجها (مثل LevelsScreen)
        unsubscribe = NetInfo.addEventListener(state => { /* setIsConnected(state.isConnected) */ }); // مثال
        // await fetchLevels(); // إذا كانت fetchLevels تقوم بتحميل بيانات عند بدء التطبيق، ابقها
      } catch (error) {
        console.error('❌ Failed to initialize DB:', error);
        Alert.alert('خطأ', 'فشل في تهيئة قاعدة البيانات المحلية');
      }
    };
    initializeApp();
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);


  if (!loaded) {
    return null;
  }

  return (
    <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
      <Stack>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style="auto" />
    </ThemeProvider>
  );
}
