// app/(tabs)/students.tsx
import { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  FlatList,
  Alert,
  Modal,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  ScrollView,
} from 'react-native';
import { supabase } from '@/lib/supabase';
import { Ionicons } from '@expo/vector-icons';
import SearchBar from '@/components/SearchBar';
import {
  getLocalStudents,
  insertLocalStudent,
  updateLocalStudent,
  deleteLocalStudent,
  updateLocalStudentSupabaseId,
  Student,
  markStudentAsSynced,
  markRemoteDeletedLocally,
  updateLocalStudentFieldsBySupabase,
  insertFromSupabaseIfNotExists,
  deleteLocalStudentByUuidAndMarkSynced,
} from '@/lib/studentsDb';
import { getLocalOffices } from '@/lib/officesDb'; // استخدم getLocalLevels للمراكز أيضًا
import { getLocalLevels } from '@/lib/levelsDb';
import { getUnsyncedChanges, clearSyncedChange } from '@/lib/syncQueueDb';
import NetInfo from '@react-native-community/netinfo';


const EmptyState = () => (
  <View style={styles.emptyState}>
    <Ionicons name="folder-open-outline" size={64} color="#d1d5db" />
    <Text style={styles.emptyStateText}>
      لا توجد طلاب حتى الآن
    </Text>
    <Text style={styles.emptyStateSubtext}>
      ابدأ بإنشاء طالب جديد
    </Text>
  </View>
);


export default function StudentsScreen() {
  const [students, setStudents] = useState<Student[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [offices, setOffices] = useState<any[]>([]);
  const [levels, setLevels] = useState<any[]>([]);
  
  // حقول النموذج
  const [name, setName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [selectedOffice, setSelectedOffice] = useState<number | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<number | null>(null);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [isConnected, setIsConnected] = useState<boolean | null>(null);

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    const initializeStudentsScreen = async () => {
      try {
        unsubscribe = NetInfo.addEventListener(state => setIsConnected(state.isConnected));
        await Promise.all([
          fetchStudents(),
          loadOfficesAndLevels()
        ]);
      } catch (error) {
        console.error('❌ Failed to prepare StudentsScreen:', error);
        Alert.alert('خطأ', 'فشل في تهيئة شاشة الطلاب');
      }
    };
    initializeStudentsScreen();
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  const loadOfficesAndLevels = async () => {
    try {
      const [officesData, levelsData] = await Promise.all([
        getLocalOffices(),
        getLocalLevels()
      ]);
      setOffices(officesData);
      setLevels(levelsData);
    } catch (error) {
      console.error('Error loading offices and levels:', error);
    }
  };

  const fetchStudents = useCallback(async () => {
    setLoading(true);
    try {
      const localData = await getLocalStudents();
      setStudents(localData);
      setFilteredStudents(localData);
    } catch (error: any) {
      Alert.alert('خطأ في جلب البيانات المحلية', error.message);
    } finally {
      setLoading(false);
    }
  }, []);

  const resetForm = () => {
    setName('');
    setBirthDate('');
    setPhone('');
    setAddress('');
    setSelectedOffice(null);
    setSelectedLevel(null);
    setEditingId(null);
  };

  const handleSave = async () => {
    if (!name.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال اسم الطالب');
      return;
    }
    if (!selectedOffice) {
      Alert.alert('خطأ', 'يرجى اختيار المركز');
      return;
    }
    if (!selectedLevel) {
      Alert.alert('خطأ', 'يرجى اختيار المستوى');
      return;
    }

    try {
      const studentData = {
        name,
        birth_date: birthDate || undefined,
        phone: phone || undefined,
        address: address || undefined,
        office_id: selectedOffice,
        level_id: selectedLevel
      };

      if (editingId) {
        await updateLocalStudent(editingId, studentData);
      } else {
        const { localId, uuid } = await insertLocalStudent(studentData);
        console.log(`New local student created: ID=${localId}, UUID=${uuid}`);
      }

      setModalVisible(false);
      resetForm();
      await fetchStudents();

      if (isConnected) {
        await syncDataWithSupabase();
      }
    } catch (error: any) {
      Alert.alert('خطأ', error.message);
    }
  };

  const handleEdit = (student: Student) => {
    setEditingId(student.id);
    setName(student.name);
    setBirthDate(student.birth_date || '');
    setPhone(student.phone || '');
    setAddress(student.address || '');
    setSelectedOffice(student.office_id);
    setSelectedLevel(student.level_id);
    setModalVisible(true);
  };

  const handleDelete = async (id: number) => {
    Alert.alert(
      'تأكيد الحذف',
      'هل تريد حذف هذا الطالب؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteLocalStudent(id);
              await fetchStudents();
              setSearchQuery('');
              if (isConnected) {
                await syncDataWithSupabase();
              }
            } catch (error: any) {
              Alert.alert('خطأ في الحذف', error.message);
            }
          },
        },
      ]
    );
  };

const syncDataWithSupabase = useCallback(async () => {
  if (!isConnected) {
    console.log('📡 غير متصل، تخطّي المزامنة.');
    return;
  }

  try {
    const unsyncedChanges = await getUnsyncedChanges();
    if (unsyncedChanges.length === 0) return;

    console.log(`🔄 ${unsyncedChanges.length} تغييرات غير مزامنة...`);

    for (const change of unsyncedChanges) {
      if (change.entity !== 'students') continue;

      const payload = JSON.parse(change.payload);
      let syncSuccessful = false;

      try {
        if (change.operation === 'INSERT') {
          const { data, error } = await supabase
            .from('students')
            .insert({
              uuid: payload.uuid,
              name: payload.name,
              birth_date: payload.birth_date || null,
              phone: payload.phone || null,
              address: payload.address || null,
              office_id: payload.office_id,
              level_id: payload.level_id,
              created_at: payload.created_at,
              updated_at: payload.updated_at,
              is_synced: true
            })
            .select('id');

          if (error) throw error;

          if (data?.[0]?.id) {
            await updateLocalStudentSupabaseId(change.entity_local_id, payload.uuid, data[0].id);
            await markStudentAsSynced(change.entity_local_id);
            syncSuccessful = true;
          }
        }

        else if (change.operation === 'UPDATE') {
          const { error } = await supabase
            .from('students')
            .update({
              name: payload.name,
              birth_date: payload.birth_date || null,
              phone: payload.phone || null,
              address: payload.address || null,
              office_id: payload.office_id,
              level_id: payload.level_id,
              updated_at: payload.updated_at,
              is_synced: true
            })
            .eq('uuid', payload.uuid)
            .is('deleted_at', null);

          if (error) throw error;

          await markStudentAsSynced(change.entity_local_id);
          syncSuccessful = true;
        }

        else if (change.operation === 'DELETE') {
          const { error } = await supabase
            .from('students')
            .update({
              deleted_at: payload.deleted_at,
              updated_at: payload.updated_at,
              is_synced: true
            })
            .eq('uuid', payload.uuid);

          if (error) throw error;

          await markStudentAsSynced(change.entity_local_id);
          syncSuccessful = true;
        }

        if (syncSuccessful) {
          await clearSyncedChange(change.id);
          console.log(`✅ تمت مزامنة ${change.operation} للطالب UUID: ${payload.uuid}`);
        }

      } catch (error: any) {
        console.error(`❌ خطأ أثناء مزامنة ${change.operation}:`, error.message);
        Alert.alert('خطأ في المزامنة', error.message);
      }
    }

    await fetchStudents();
    await fetchRemoteStudentsAndMerge();
  } catch (error: any) {
    console.error('❌ خطأ غير متوقع أثناء المزامنة:', error.message);
  }
}, [isConnected, fetchStudents, fetchRemoteStudentsAndMerge]);

const fetchRemoteStudentsAndMerge = useCallback(async () => {
    if (!isConnected) return;

    try {
      const { data: remoteStudents, error } = await supabase
        .from('students')
        .select('*')
        .order('id', { ascending: true });
      if (error) throw error;

      const localStudents = await getLocalStudents();

      await Promise.all(remoteStudents.map(async (remoteStudent) => {
        if (remoteStudent.deleted_at) {
          const existingLocal = localStudents.find(l => l.uuid === remoteStudent.uuid);
          if (existingLocal && !existingLocal.deleted_at) {
            await markRemoteDeletedLocally(remoteStudent.id, remoteStudent.deleted_at);
            console.log(`🗑️ Marked remote deleted student locally: ${remoteStudent.name}`);
          }
          return;
        }

        const localStudent = localStudents.find(l => l.uuid === remoteStudent.uuid);

        if (!localStudent) {
          await insertFromSupabaseIfNotExists(remoteStudent);
          console.log(`➕ Inserted new student from Supabase: ${remoteStudent.name}`);
        } else {
          const remoteUpdate = new Date(remoteStudent.updated_at || remoteStudent.created_at || 0).getTime();
          const localUpdate = new Date(localStudent.updated_at || localStudent.created_at || 0).getTime();

          if (remoteUpdate > localUpdate) {
            await updateLocalStudentFieldsBySupabase(remoteStudent);
            console.log(`🔄 Updated local student from Supabase: ${localStudent.name}`);
          }
        }
      }));

      await fetchStudents();
    } catch (error: any) {
      console.error('❌ Error fetching remote students:', error.message);
      Alert.alert('خطأ في جلب بيانات Supabase', error.message);
    }
  }, [isConnected, fetchStudents]);


  const renderStudentItem = ({ item, index }: { item: Student; index: number }) => (
    <View style={styles.studentItem}>
      <View style={styles.studentInfo}>
        <View style={styles.serialNumber}>
          <Text style={styles.serialText}>{index + 1}</Text>
        </View>
        <View style={styles.studentDetails}>
          <Text style={styles.studentName}>{item.name}</Text>
          {item.birth_date && <Text style={styles.studentDetail}>تاريخ الميلاد: {item.birth_date}</Text>}
          {item.phone && <Text style={styles.studentDetail}>الهاتف: {item.phone}</Text>}
          {item.address && <Text style={styles.studentDetail}>العنوان: {item.address}</Text>}
          <Text style={styles.studentDetail}>المركز: {item.office_name || 'غير محدد'}</Text>
          <Text style={styles.studentDetail}>المستوى: {item.level_name || 'غير محدد'}</Text>
          <Text style={styles.studentId}>رقم التعريف (محلي): {item.id}</Text>
          {item.supabase_id && (
            <Text style={styles.studentId}>رقم التعريف (Supabase): {item.supabase_id}</Text>
          )}
          {item.operation_type && (
            <Text style={styles.studentId}>
              حالة المزامنة:{' '}
              <Text style={{ color: 'orange', fontWeight: 'bold' }}>
                معلق ({item.operation_type})
              </Text>
            </Text>
          )}
        </View>
      </View>
      <View style={styles.studentActions}>
        <TouchableOpacity
          style={[styles.actionButton, styles.editButton]}
          onPress={() => handleEdit(item)}
        >
          <Ionicons name="create-outline" size={18} color="#3b82f6" />
          <Text style={styles.editText}>تعديل</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.actionButton, styles.deleteButton]}
          onPress={() => handleDelete(item.id)}
        >
          <Ionicons name="trash-outline" size={18} color="#ef4444" />
          <Text style={styles.deleteText}>حذف</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f8fafc" />

      <View style={styles.header}>
        <Text style={styles.title}>الطلاب</Text>
        <TouchableOpacity style={styles.addButton} onPress={() => {
          setModalVisible(true);
          resetForm();
        }}>
          <Ionicons name="add-circle" size={24} color="white" />
          <Text style={styles.addButtonText}>طالب جديد</Text>
        </TouchableOpacity>
      </View>

      {isConnected !== null && (
        <View style={styles.connectionStatus}>
          <Text style={{ color: isConnected ? '#16a34a' : '#dc2626', fontWeight: 'bold' }}>
            {isConnected ? 'متصل بالإنترنت' : 'غير متصل بالإنترنت'}
          </Text>
        </View>
      )}

      <SearchBar searchQuery={searchQuery} setSearchQuery={setSearchQuery} />

      {searchQuery.length > 0 && students.length > 0 && (
        <View style={styles.resultsContainer}>
          <Text style={styles.resultsText}>{filteredStudents.length} من {students.length} طالب</Text>
        </View>
      )}

      <FlatList
        data={filteredStudents}
        keyExtractor={item => item.uuid || item.id.toString()}
        refreshing={loading}
        onRefresh={async () => {
          await fetchStudents();
          if (isConnected) {
            await syncDataWithSupabase();
          }
        }}
        renderItem={renderStudentItem}
        ListEmptyComponent={EmptyState}
        contentContainerStyle={styles.listContent}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />

      <Modal
        visible={modalVisible}
        animationType="fade"
        transparent
        onRequestClose={() => {
          setModalVisible(false);
          resetForm();
        }}
      >
        <View style={styles.modalOverlay}>
          <ScrollView contentContainerStyle={styles.modalScroll}>
            <View style={styles.modalContainer}>
              <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>
                  {editingId ? 'تعديل الطالب' : 'إنشاء طالب جديد'}
                </Text>
                <TouchableOpacity
                  style={styles.closeButton}
                  onPress={() => {
                    setModalVisible(false);
                    resetForm();
                  }}
                >
                  <Ionicons name="close" size={24} color="#6b7280" />
                </TouchableOpacity>
              </View>

              <View style={styles.modalBody}>
                <Text style={styles.label}>اسم الطالب *</Text>
                <TextInput
                  value={name}
                  onChangeText={setName}
                  placeholder="أدخل اسم الطالب"
                  style={styles.input}
                />

                <Text style={styles.label}>تاريخ الميلاد</Text>
                <TextInput
                  value={birthDate}
                  onChangeText={setBirthDate}
                  placeholder="YYYY-MM-DD"
                  style={styles.input}
                />

                <Text style={styles.label}>رقم الهاتف</Text>
                <TextInput
                  value={phone}
                  onChangeText={setPhone}
                  placeholder="أدخل رقم الهاتف"
                  style={styles.input}
                  keyboardType="phone-pad"
                />

                <Text style={styles.label}>عنوان السكن</Text>
                <TextInput
                  value={address}
                  onChangeText={setAddress}
                  placeholder="أدخل عنوان السكن"
                  style={styles.input}
                />

                <Text style={styles.label}>المركز *</Text>
                <View style={styles.pickerContainer}>
                  {offices.map(office => (
                    <TouchableOpacity
                      key={office.id}
                      style={[
                        styles.pickerItem,
                        selectedOffice === office.supabase_id && styles.selectedPickerItem
                      ]}
                      onPress={() => setSelectedOffice(office.supabase_id)}
                    >
                      <Text>{office.name}</Text>
                    </TouchableOpacity>
                  ))}
                </View>

                <Text style={styles.label}>المستوى *</Text>
                <View style={styles.pickerContainer}>
                  {levels.map(level => (
                    <TouchableOpacity
                      key={level.id}
                      style={[
                        styles.pickerItem,
                        selectedLevel === level.supabase_id && styles.selectedPickerItem
                      ]}
                      onPress={() => setSelectedLevel(level.supabase_id)}
                    >
                      <Text>{level.name}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <View style={styles.modalFooter}>
                <TouchableOpacity
                  style={[styles.modalButton, styles.cancelButton]}
                  onPress={() => {
                    setModalVisible(false);
                    resetForm();
                  }}
                >
                  <Text style={styles.cancelText}>إلغاء</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.modalButton, styles.saveButton]}
                  onPress={handleSave}
                >
                  <Text style={styles.saveText}>{editingId ? 'تحديث' : 'إنشاء'}</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8fafc' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  title: { fontSize: 28, fontWeight: 'bold', color: '#1e293b' },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#6366f1',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 8,
  },
  addButtonText: { color: 'white', fontWeight: '600', fontSize: 14 },
  connectionStatus: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#dcfce7',
    alignItems: 'center',
  },
  resultsContainer: { marginHorizontal: 16, marginBottom: 12 },
  resultsText: { fontSize: 14, color: '#64748b' },
  listContent: { paddingHorizontal: 16, paddingBottom: 20 },
  studentItem: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    marginBottom: 8,
  },
  studentInfo: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  serialNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#e0e7ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  serialText: { fontSize: 14, fontWeight: 'bold', color: '#6366f1' },
  studentDetails: { flex: 1 },
  studentName: { fontSize: 16, fontWeight: '600', color: '#1e293b', marginBottom: 4 },
  studentDetail: { fontSize: 14, color: '#6b7280', marginBottom: 2 },
  studentId: { fontSize: 12, color: '#6b7280' },
  studentActions: { flexDirection: 'row', gap: 8 },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  editButton: { backgroundColor: '#eff6ff' },
  deleteButton: { backgroundColor: '#fef2f2' },
  editText: { color: '#3b82f6', fontSize: 12, fontWeight: '600' },
  deleteText: { color: '#ef4444', fontSize: 12, fontWeight: '600' },
  separator: { height: 8 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalScroll: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  modalContainer: {
    backgroundColor: 'white',
    borderRadius: 16,
    maxWidth: 400,
    width: '100%',
    alignSelf: 'center',
    elevation: 8,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#1e293b' },
  closeButton: { padding: 4 },
  modalBody: { padding: 20 },
  label: { fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 8 },
  input: {
    borderWidth: 1,
    borderColor: '#d1d5db',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 16,
    color: '#1e293b',
    textAlign: 'right',
    marginBottom: 12,
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: '#d1d5db',
    borderRadius: 8,
    marginBottom: 12,
  },
  pickerItem: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  selectedPickerItem: {
    backgroundColor: '#e0e7ff',
  },
  modalFooter: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 12,
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  modalButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    minWidth: 80,
    alignItems: 'center',
  },
  cancelButton: { backgroundColor: '#f3f4f6' },
  saveButton: { backgroundColor: '#6366f1' },
  cancelText: { color: '#374151', fontWeight: '600' },
  saveText: { color: 'white', fontWeight: '600' },

   emptyState: {
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center',
  paddingVertical: 60,
},
emptyStateText: { fontSize: 18, color: '#6b7280', marginTop: 16 },
emptyStateSubtext: { fontSize: 14, color: '#9ca3af', marginTop: 4 }, 
    
});